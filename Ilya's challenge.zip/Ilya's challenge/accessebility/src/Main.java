public class Main {
    public static void main(String[] args) {
        try {
            Intern intern = new Intern("EPFL", 112590, "Iliya Asadi", "iliya70594@gmail.com", "Iran", "Computer Science", "Machine Learning", 1);
            intern.showDetails();

            Intern.changeCountry(112590, "Switzerland");
            System.out.println("Updated country for nationalID 112590: " + Intern.getCountryByNationalID(112590));

            Intern.changeCountry(123456, "Germany");
            System.out.println("Country for nationalID 123456: " + Intern.getCountryByNationalID(123456));

            Intern.removeMember(123456);
            System.out.println("Country for nationalID 123456 after removal: " + Intern.getCountryByNationalID(123456));

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}