import java.util.HashMap;

public abstract class TeamMember {
    private String nameOfInstitute;
    private long nationalID;
    private String fullName;
    private String email;
    private String country;
    protected String faculty;

    protected TeamMember(String nameOfInstitute, long nationalID, String fullName, String email, String country, String faculty) {
        setNameOfInstitute(nameOfInstitute);
        setNationalID(nationalID);
        setFullName(fullName);
        setEmail(email);
        setCountry(country);
        this.faculty = faculty;
    }

    public String getNameOfInstitute() {
        return nameOfInstitute;
    }

    public void setNameOfInstitute(String nameOfInstitute) {
        if (nameOfInstitute == null || nameOfInstitute.isEmpty() || !Character.isUpperCase(nameOfInstitute.charAt(0))) {
            throw new IllegalArgumentException("Name of institute must start with a capital letter.");
        }
        this.nameOfInstitute = nameOfInstitute;
    }

    public long getNationalID() {
        return nationalID;
    }

    public void setNationalID(long nationalID) {
        if (nationalID >= 100000 ) {
            throw new IllegalArgumentException("National ID must be at least a 6-digit positive number.");
        }
        this.nationalID = nationalID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        if (fullName == null || fullName.isEmpty() || !Character.isUpperCase(fullName.charAt(0))) {
            throw new IllegalArgumentException("Full name must start with a capital letter.");
        }
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Email must contain '@'.");
        }
        this.email = email;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        if (country == null || country.isEmpty() || !Character.isUpperCase(country.charAt(0))) {
            throw new IllegalArgumentException("Country must start with a capital letter.");
        }
        this.country = country;
    }

    protected abstract void showDetails();


    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
}

 class Intern extends TeamMember {
    private String requestedField;
    private int internID;
    private static HashMap<Long, String> countryOfEachMember = new HashMap<>();

    public Intern(String nameOfInstitute, long nationalID, String fullName, String email, String country, String faculty, String requestedField, int internID) {
        super(nameOfInstitute, nationalID, fullName, email, country, faculty);
        setRequestedField(requestedField);
        setInternID(internID);
        countryOfEachMember.put(nationalID, country);
    }

    public String getRequestedField() {
        return requestedField;
    }

    public void setRequestedField(String requestedField) {
        this.requestedField = requestedField;
    }

    public int getInternID() {
        return internID;
    }

    public void setInternID(int internID) {
        if (internID < 0) {
            throw new IllegalArgumentException("Intern ID cannot be negative.");
        }
        this.internID = internID;
    }

    @Override
    public void showDetails() {
        System.out.println("Member type: Intern");
        System.out.println("Name of institute: " + getNameOfInstitute());
        System.out.println("Name: " + getFullName());
        System.out.println("NationalID: " + getNationalID());
        System.out.println("Email: " + getEmail());
        System.out.println("Faculty: " + faculty);
        System.out.println("Requested field: " + requestedField);
        System.out.println("ID: " + internID);
        System.out.println("---------------------");
    }

     public static void changeCountry(long nationalID, String country) {
         if (nationalID < 100000 || nationalID > 999999) {
             throw new IllegalArgumentException("National ID must be a 6-digit positive number.");
         }
         if (country == null || country.isEmpty() || !Character.isUpperCase(country.charAt(0))) {
             throw new IllegalArgumentException("Country must start with a capital letter.");
         }
         countryOfEachMember.put(nationalID, country);
     }

     public static String getCountryByNationalID(long nationalID) {
         return countryOfEachMember.get(nationalID);
     }

     public static void removeMember(long nationalID) {
         countryOfEachMember.remove(nationalID);
     }
 }